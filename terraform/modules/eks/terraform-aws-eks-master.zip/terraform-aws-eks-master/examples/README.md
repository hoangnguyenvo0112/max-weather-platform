# Examples

The examples provided demonstrate different cluster configurations that users can create with the modules provided.

Please do not mistake the examples provided as "best practices". It is up to users to consult the AWS service documentation for best practices, usage recommendations, etc.
