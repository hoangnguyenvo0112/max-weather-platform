[string]$Something = 'IDoNotKnowAnyPowerShell ¯\_(ツ)_/¯'
